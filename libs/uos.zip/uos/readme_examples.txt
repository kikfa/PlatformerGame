All examples are using uos_flat.

uos_flat is a over-layer for uos that takes care about class declarations.
You do not have to declare anything in your main application.
All methods have a "universal procedurial" syntax.

If you prefer to use uos directly, SimplePlayer_noflat shows how to do.
This way all methods can be used as oop. (java flavour).


Warning: to play Opus files, you should:

For Windows:
copy /uos/examples/lib/Windows/32bit/libopus-0.dll
and paste into your windows/system directory.

For Linux/FreeBSD:
copy /uos/examples/lib/Linux-or-FreeBSD/64it/libopus.so
and paste into /usr/local/lib directory

Fre;D




